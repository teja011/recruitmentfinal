package com.cg.rms.service;

import java.util.List;
import com.cg.rms.dao.RecruitmentDao;
import com.cg.rms.dao.RecruitmentDaoImpl;
import com.cg.rms.dto.Admin;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.dto.JobRequirements;
import com.cg.rms.exception.RecruitmentException;


public class CourseServiceImpl implements CourseService {

	private RecruitmentDao cdao  = new RecruitmentDaoImpl(); 
	
	
	
	@Override
	public String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException {
		
		return cdao.insertCourse(cource);
	}
	
	
	
	@Override
	public String insertCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory)
			throws RecruitmentException {
	
		return cdao.insertCandidateWorkHistory(chistory);
	}
	
	
	@Override
	public String insertCandidateBeanQualification( CandidateBeanQualification cqualifications)
			throws RecruitmentException {
	
		return cdao.insertCandidateQualifications(cqualifications);
	}
	
	
	
	/*@Override
	public List<CandidateBeanPersonal> getAllCourses() throws RecruitmentException {
		
		return cdao.gatAllCourses();
	}*/
	@Override
	public boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException {
		
	
		return cdao.updateCourse(cource);
	}



	@Override
	public int login(String username, String password, String role)
			throws RecruitmentException {
		
		return cdao.login(username, password, role);
	}



	@Override
	public boolean updateCandidateBeanQualification(
			CandidateBeanQualification cqualifications)
			throws RecruitmentException {
		
		return cdao.updateCandidateQualifications(cqualifications);
	}



	@Override
	public boolean updatCandidateBeanWorkHistory(CandidateBeanWorkHistory chistory)
			throws RecruitmentException {
		
		return cdao.updatCandidateWorkHistory(chistory);
	}


	@Override
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.addCompanyDetails(cmaster);
	}



	@Override
	public boolean updateCompanyDetails() throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.updateCompanyDetails();
	}
	@Override
	public List<CandidateBeanQualification> searchjobs(String jreq)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.searchjobs(jreq);
	}

	@Override
	public List<CandidateBeanWorkHistory> searchjobs2(String jreq)
			throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.searchjobs2(jreq);
	}



	@Override
	public List<JobRequirements> searchjobs3(JobRequirements jreq) throws RecruitmentException {
		// TODO Auto-generated method stub
		return cdao.searchjobs3(jreq);
	}



	@Override
	public int insertJobReq(JobRequirements jreq) throws RecruitmentException {
		
		return cdao.insertJobReq(jreq);
	}



	@Override
	public int apply(String candidate_id, String job_id,String company_id) throws RecruitmentException {
		
		return cdao.apply(candidate_id, company_id,job_id);
	}



	@Override
	public List<Admin> getAllCandidate() throws RecruitmentException {
		
		return cdao.gatAllCandidate();
	}

	
	
/*	@Override
	public boolean validateCourse(CandidateBeanPersonal c) throws RecruitmentException {
		if(!c.getCandidate_name().matches("[A-Za-z]")) {
			throw new RecruitmentException("should start with capital letter");
		}
		if(!c.getAddress().matches("[A-Za-z]")) {
			throw new RecruitmentException("Address should be alphabets");
		}
		if (!c.getDOB().matches("[0-9]")) {
			throw new RecruitmentException("DOB should be numbers");	
		}
		if(!c.getContact_number().matches("[0-9]{10}")) {
			throw new RecruitmentException("Should be 10 digits");
		}
		if(!c.getPassport_number().matches("[0-9]")) {
			throw new RecruitmentException("passport should be number");
		}
		//if(!c.getEmail_id().matches("[0-9]")) {
		//	throw new RecruitmentException("should be number");
		//}
		return true;
		
	}



	@Override
	public boolean validateCandiQualif(CandidateBeanQualification cqualifications) throws RecruitmentException {
		if(!cqualifications.getQualification_name().matches("[A-Za-z]")) {
			throw new RecruitmentException("Qualification name should start with Capital letters");
		}
		if(!cqualifications.getSpecialization_area().matches("[A-Za-z]")) {
			throw new RecruitmentException("Specialization name should start with Capital letters");
		}
		if(!cqualifications.getCollege_name().matches("[A-Za-z]")) {
			throw new RecruitmentException("College name should start with Capital letters");
		}
		if(!cqualifications.getUniversity_name().matches("[A-Za-z]")) {
			throw new RecruitmentException("University name should start with Capital letters");
		}
		if (!cqualifications.getPercentage().matches("[0-9]")) {
			throw new RecruitmentException("Enter numbers");	
		}
		return true;

	}
*/
}

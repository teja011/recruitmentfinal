package com.cg.rms.dto;

public class Admin {
	
String candidate_id;
String company_id;
String job_id;
String status;
public Admin(String candidate_id, String company_id, String job_id, String status) {
	super();
	this.candidate_id = candidate_id;
	this.company_id = company_id;
	this.job_id = job_id;
	this.status = status;
}
public String getCandidate_id() {
	return candidate_id;
}
public void setCandidate_id(String candidate_id) {
	this.candidate_id = candidate_id;
}
public String getCompany_id() {
	return company_id;
}
public void setCompany_id(String company_id) {
	this.company_id = company_id;
}
public String getJob_id() {
	return job_id;
}
public void setJob_id(String job_id) {
	this.job_id = job_id;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Admin [candidate_id=" + candidate_id + ", company_id=" + company_id + ", job_id=" + job_id + ", status="
			+ status + "]";
}
public Admin() {
	super();
}



	

}

package com.cg.rms.dao;

import java.util.List;

import com.cg.rms.dto.Admin;
import com.cg.rms.dto.CandidateBeanPersonal;
import com.cg.rms.dto.CandidateBeanQualification;
import com.cg.rms.dto.CandidateBeanWorkHistory;
import com.cg.rms.dto.CompanyMaster;
import com.cg.rms.dto.JobRequirements;

import com.cg.rms.exception.RecruitmentException;

//Dao Interface

public interface RecruitmentDao {
	//Methods for Inserting details of candidate, inserting resume.
	String insertCourse(CandidateBeanPersonal cource) throws RecruitmentException;
    String insertCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException;
    String insertCandidateWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
    
	//methods for updating details of candidate, updating resume.
	boolean updateCourse(CandidateBeanPersonal cource) throws RecruitmentException;
	boolean updateCandidateQualifications(CandidateBeanQualification cqualifications) throws RecruitmentException;
	boolean updatCandidateWorkHistory(CandidateBeanWorkHistory chistory) throws RecruitmentException;
	
	//method for inserting company details by particular company.
	public String addCompanyDetails(CompanyMaster cmaster) throws RecruitmentException;
	
	//method for updating particular company details.
	public boolean updateCompanyDetails() throws RecruitmentException;
	
	//method for login to various users of applications.
    public int login(String username, String password, String role)throws RecruitmentException;
    
    //method for company to search candidate on various criteria
    List<CandidateBeanQualification> searchjobs(String jreq) throws RecruitmentException;
	List<CandidateBeanWorkHistory> searchjobs2(String jreq)	throws RecruitmentException;
	
	//method for candidate to search for various jobs. 
	List<JobRequirements> searchjobs3(JobRequirements jreq) throws RecruitmentException;
	
	//method for inserting various job by company
	public int insertJobReq(JobRequirements jreq) throws RecruitmentException;
	
	//method for canndidate to apply for a particular job
	int apply(String candidate_id,String job_id,String company_id) throws RecruitmentException;
	
	//method that allows admin to show report on his home page.
	  public List<Admin> gatAllCandidate() throws RecruitmentException;
	  
	  
	  
} 